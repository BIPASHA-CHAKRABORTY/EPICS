# Yatra Genie 🧞‍♂️

Yatra Genie is an AI-powered travel planner designed for Indian destinations.
It generates personalized itineraries based on travel type, budget, and duration using AI and real-world APIs.

### Features
- AI-generated itineraries
- India-focused destinations
- Budget-aware planning
- Solo, family & friends travel modes
- Save & share trips
